# Mahakal Trading Company — full-stack starter

Owner displayed on the website: Rajesh Patel.

## Included
- Responsive carrot and beetroot wholesale enquiry website.
- Backend `POST /api/orders` validates and stores enquiries in `data/orders.json`.
- Health check: `GET /api/health`.
- Basic password-protected admin endpoints:
  - `GET /api/admin/orders` with header `x-admin-password`
  - `PATCH /api/admin/orders/:id` with JSON body `{ "status": "Quote sent" }` and the same header.
- Payment preference selection only. No payment is collected or verified.

## Run on Replit from a phone
1. Create a Node.js Repl.
2. Upload/extract the project ZIP so `package.json`, `server.js`, and `public/index.html` are in the shown structure.
3. Add a Replit Secret named `ADMIN_PASSWORD` with a long unique password.
4. Press Run. The start command is `npm start`.
5. Open `/api/health` on the Replit web URL to test the backend.
6. Submit a sample enquiry from the website and check that it returns an enquiry reference.

## Important
- This is a working starter backend, not a production-grade commerce platform.
- `data/orders.json` may not be durable across some hosting resets. Use a managed database for real orders.
- Real UPI QR/payment requires verified merchant credentials and server-side gateway integration and payment verification. No secret keys should be placed in public HTML.
- Replace demo phone/email/address and add accurate shipping, privacy, terms and cancellation/refund details before publishing.
- Verify payment in the merchant dashboard before dispatch; do not rely on a screenshot.
