const express = require("express");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, "data");
const ORDERS_FILE = path.join(DATA_DIR, "orders.json");

app.use(express.json({ limit: "100kb" }));
app.use(express.static(path.join(__dirname, "public")));

function ensureStorage() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(ORDERS_FILE)) fs.writeFileSync(ORDERS_FILE, "[]", "utf8");
}
function readOrders() {
  ensureStorage();
  try { return JSON.parse(fs.readFileSync(ORDERS_FILE, "utf8")); } catch { return []; }
}
function writeOrders(orders) {
  ensureStorage();
  fs.writeFileSync(ORDERS_FILE, JSON.stringify(orders, null, 2), "utf8");
}
function clean(v, max = 500) { return typeof v === "string" ? v.trim().slice(0, max) : ""; }

app.get("/api/health", (_req, res) => res.json({ ok: true, app: "Mahakal Trading Company", owner: "Rajesh Patel" }));

app.post("/api/orders", (req, res) => {
  const b = req.body || {};
  const buyer = clean(b.buyer, 120), phone = clean(b.phone, 40), city = clean(b.city, 120);
  const email = clean(b.email, 180), delivery = clean(b.delivery, 120);
  const requiredDate = clean(b.requiredDate, 30), notes = clean(b.notes, 1500);
  const paymentPreference = clean(b.paymentPreference, 80);
  const rawItems = b.items && typeof b.items === "object" ? b.items : {};
  const items = {};
  for (const key of ["Carrot", "Beetroot"]) {
    const n = Number(rawItems[key]);
    if (Number.isFinite(n) && n > 0 && n <= 1000000) items[key] = n;
  }
  if (!buyer || !phone || !city || !Object.keys(items).length)
    return res.status(400).json({ error: "Name/company, phone, city and at least one valid product quantity are required." });
  const orders = readOrders();
  const order = {
    orderId: "MTC-" + Date.now().toString(36).toUpperCase() + "-" + crypto.randomBytes(2).toString("hex").toUpperCase(),
    createdAt: new Date().toISOString(), status: "Enquiry received",
    paymentStatus: "Not paid / not verified", company: "Mahakal Trading Company", owner: "Rajesh Patel",
    buyer, phone, email, city, delivery, requiredDate, items, notes, paymentPreference
  };
  orders.unshift(order);
  writeOrders(orders);
  res.status(201).json({ ok: true, orderId: order.orderId, message: "Enquiry saved. No payment was collected." });
});

app.get("/api/admin/orders", (req, res) => {
  const expected = process.env.ADMIN_PASSWORD;
  if (!expected) return res.status(503).json({ error: "Set ADMIN_PASSWORD in Replit Secrets first." });
  if (req.get("x-admin-password") !== expected) return res.status(401).json({ error: "Unauthorized." });
  res.json({ ok: true, orders: readOrders() });
});

app.patch("/api/admin/orders/:id", (req, res) => {
  const expected = process.env.ADMIN_PASSWORD;
  if (!expected) return res.status(503).json({ error: "Set ADMIN_PASSWORD in Replit Secrets first." });
  if (req.get("x-admin-password") !== expected) return res.status(401).json({ error: "Unauthorized." });
  const allowed = ["Enquiry received", "Quote sent", "Confirmed", "Dispatched", "Delivered", "Cancelled"];
  const status = clean(req.body && req.body.status, 40);
  if (!allowed.includes(status)) return res.status(400).json({ error: "Invalid status." });
  const orders = readOrders();
  const order = orders.find(o => o.orderId === req.params.id);
  if (!order) return res.status(404).json({ error: "Order not found." });
  order.status = status; writeOrders(orders); res.json({ ok: true, order });
});

app.get("*", (req, res, next) => {
  if (req.path.startsWith("/api/")) return next();
  res.sendFile(path.join(__dirname, "public", "index.html"));
});
app.listen(PORT, "0.0.0.0", () => { ensureStorage(); console.log(`Server running on port ${PORT}`); });
